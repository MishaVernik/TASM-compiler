import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class Thread4 extends  Thread  {

    CommonResource1 CR1;
    CommonResource2 CR2;
    Thread thread;
    CyclicBarrier cyclicBarrier2;

    Thread4 (CommonResource1 CR1, CommonResource2 CR2, CyclicBarrier cyclicBarrier2){
        this.CR1 = CR1;
        this.CR2 = CR2;
        this.cyclicBarrier2 = cyclicBarrier2;
        thread = new Thread (this, "Thread4");
        thread.start();
    }


    @Override
    public void run(){
        System.out.println("---4- Thread" + " started!");

        while (Extra.shitReset) {
            CR1.getNumber(Character.getNumericValue(thread.getName().charAt(6)));

            // Cyclic Barrier 2

            System.out.println("---4- Thread" + " waiting for barrier124!");

            try {
                cyclicBarrier2.await();

            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (BrokenBarrierException e) {
                e.printStackTrace();
            }
            System.out.println("---4- Thread" + " broke down barrier124!");

            // mutex region
            Extra.mutex.lock();

            CR2.int1 = 988;
            CR2.boolean1 = true;
            CR2.long1 = 4000;
            CR2.short1 = 32;
            CR2.char1 = 'Z';

            System.out.println("---4- Thread" + " modified CR2!");
            System.out.println("---4- Thread" + " unlock mutex!");
            Extra.mutex.unlock();
        }
        System.out.println("EXIT4");
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        cyclicBarrier2.reset();
       // System.exit(0);
    }
}
