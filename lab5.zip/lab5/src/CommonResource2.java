public class CommonResource2 {
    int int1;
    float float1;
    double double1;
    boolean boolean1;
    long long1;
    short short1;
    char char1;

}
