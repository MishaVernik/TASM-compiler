import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class Thread1 extends  Thread {

    CommonResource2 CR2;
    Thread thread;
    CyclicBarrier cyclicBarrier;

    Thread1 (CommonResource2 CR2, CyclicBarrier cyclicBarrier){
        this.cyclicBarrier = cyclicBarrier;
        this.CR2 = CR2;
        thread = new Thread (this, "Thread1");
        thread.start();
    }


    @Override
    public void run(){
        System.out.println("1---- Thread" + " started!");
        while(Extra.shitReset){
            // Cyclic Barrier
            System.out.println("1---- Thread" + " waiting for barrier124!");
            try {
                cyclicBarrier.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (BrokenBarrierException e) {
                e.printStackTrace();
            }
            System.out.println("1---- Thread" + " broke down barrier124!");

            //mutex part
            Extra.mutex.lock();
            int c = CR2.int1;
            Extra.mutex.unlock();
        }
        System.out.println("EXIT1");
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        cyclicBarrier.reset();
    }
}
