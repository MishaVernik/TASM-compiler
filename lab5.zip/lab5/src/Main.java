import java.util.concurrent.CyclicBarrier;
import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.ReentrantLock;

public class Main {


    public static void main(String[] args) {
        CyclicBarrier barrier124 = new CyclicBarrier(3);

        CommonResource1 CR1 = new CommonResource1();
        CommonResource2 CR2 = new CommonResource2();

        Thread1 thread1 = new Thread1 (CR2, barrier124);
        Thread2 thread2 = new Thread2 (barrier124, CR2, CR1);
        Thread3 thread3 = new Thread3 (CR1);
        Thread4 thread4 = new Thread4 (CR1,CR2, barrier124);
        Thread5 thread5 = new Thread5 (CR1);

        try{
            thread1.thread.join();
            thread2.thread.join();
            thread3.thread.join();
            thread4.thread.join();
            thread5.thread.join();
        }catch(InterruptedException e){
            System.out.println(e.getMessage());
        }

    }
}
