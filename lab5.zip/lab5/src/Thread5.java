import org.jetbrains.annotations.NotNull;

import java.util.Random;
import java.util.concurrent.*;

public class Thread5 extends  Thread  {

    CommonResource1 CR1;
    Thread thread;

    Thread5 (CommonResource1 CR1){
        this.CR1= CR1;
        thread = new Thread (this, "Thread5");
        thread.start();
    }


    @Override
    public void run(){
        System.out.println("----5 Thread" + " started!");
        while (Extra.shitReset) {
            // full synchronization
        /*
        1. Release Semaphore1
        2. Acquire Semaphore2
        3. Release Semaphore2
        4. Acquire Semaphore1
         */

            Extra.semaphoreSynchronization(Extra.thread5_sem2, Extra.thread3_sem1);
            // Access via monitor to CR1
            CR1.putNumber(new Random().nextInt(10000),  Character.getNumericValue(thread.getName().charAt(6)));

        }
        System.out.println("EXIT5");
        Extra.thread5_sem2.release();
        Extra.thread3_sem1.release();

    }

}
