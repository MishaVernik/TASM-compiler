import java.util.Random;
import java.util.concurrent.BrokenBarrierException;
import java.util.concurrent.CyclicBarrier;

public class Thread2 extends  Thread  {

    CommonResource2 CR2;
    Thread thread;
    CyclicBarrier cyclicBarrier;
    CommonResource1 CR1;
    Thread2(CyclicBarrier cyclicBarrier, CommonResource2 CR2, CommonResource1 CR1){
        this.CR2 = CR2;
        this.CR1 = CR1;
        this.cyclicBarrier = cyclicBarrier;
        thread = new Thread(this,"Thread2");
        thread.start();
    }

    @Override
    public void run(){
        System.out.println("-2--- Thread" + " started!");
        while(Extra.shitReset){
            Extra.mutex.lock();
            // Change CR2 data
            CR2.char1 = 'e';
            CR2.int1 = 2;
            Extra.mutex.unlock();


            // Cyclic Barrier 124
            System.out.println("-2--- Thread" + " waiting for barrier124!");
            try {
                cyclicBarrier.await();
            } catch (InterruptedException e) {
                e.printStackTrace();
            } catch (BrokenBarrierException e) {
                e.printStackTrace();
            }
            System.out.println("-2--- Thread" +  " broke down barrier124!");
            // Access to the CR1 via monitor
            /// put data
            CR1.putNumber(new Random().nextInt(10000), Character.getNumericValue(thread.getName().charAt(6)));
        }
        System.out.println("EXIT2");
        try {
            Thread.sleep(100);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        cyclicBarrier.reset();
    }
}
