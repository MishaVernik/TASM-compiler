import org.jetbrains.annotations.NotNull;

import java.util.concurrent.Semaphore;
import java.util.concurrent.locks.ReentrantLock;

public class Extra {


    public static boolean shitReset = true;
    public static boolean without_sleep = false;
    public static int restart = 0;
    public static Semaphore thread3_sem1 = new Semaphore(0, true);
    public static Semaphore thread5_sem2 = new Semaphore(0, true);
    public static ReentrantLock mutex = new ReentrantLock();

    public static void semaphoreSynchronization(@NotNull Semaphore thread5_sem2, @NotNull Semaphore thread3_sem1) {
        thread5_sem2.release();
        try {
            thread3_sem1.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        thread3_sem1.release();
        try {
            thread5_sem2.acquire();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    public static void printCurrentThread(int thread_num){
        switch(thread_num){
            case 1:
                System.out.println("1---- Thread");
                break;
            case 2:
                System.out.println("-2--- Thread");
                break;
            case 3:
                System.out.println("--3-- Thread");
                break;
            case 4:
                System.out.println("---4- Thread");
                break;
            case 5:
                System.out.println("----5 Thread");
                break;
        }
    }
}
