public class CommonResource1 {

    public static final int MAXSIZE = 100;

    static int nextIn = 0;
    static int nextOut = 0;

    static int index = 0;
    int ringBuffer[] = new int[MAXSIZE + 1];
    boolean isEmpty = index  == 0;
    boolean isFull = index == MAXSIZE;
    static int restart = 0;

    synchronized void getNumber(int thread_num){

        while (isEmpty){
            try {
                wait();
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        }
        Extra.printCurrentThread(thread_num);
        int result = ringBuffer[nextOut];
        index = nextOut;
        nextOut = (nextOut + 1) % MAXSIZE;
        System.out.println("--- Ring Buffer[" + index + "] = " + ringBuffer[index]);
        System.out.println("--- nextOut: " + index-- + " => " + nextOut);
        System.out.println();
        if (index == 80)
            Extra.shitReset = false;
        notify();

    }
    synchronized  void putNumber(int number, int thread_num){
        if(isFull) {
             restart++;
            for(int i=0; i< MAXSIZE; i++) ringBuffer[i] = 0;
            index = 0;
            System.out.println("Buffer cleaned! Restart counter: " + restart);
            isEmpty = true;
            isFull = false;
        }

        if(restart == 2) {
            System.out.println("End program!");
            System.exit(0);
        }


        while (isFull)
            try{
                wait();
            }
            catch (InterruptedException e){
                System.out.println("InterruptedException");
            }

        Extra.printCurrentThread(thread_num);
        ringBuffer[nextIn] = number;
        index = nextIn;
        nextIn = (nextIn + 1) % MAXSIZE;
        System.out.println("--- Ring Buffer[" + index + "] = " + ringBuffer[index]);

        System.out.println("--- nextIn: " + index + " => " + nextIn);
        System.out.println();

        isFull = index == MAXSIZE;
        isEmpty = false;
        if (index == 80)
            Extra.shitReset = false;

        notify();

    }
}
